import { useState, useEffect } from "react"

export interface MetricType {
  id: number
  user_id: number
  name: string
  unit: string | null
  goal: number | null
}

export interface MetricEntry {
  id: number
  metric_type_id: number
  entry_date: string
  value: number
  note?: string | null
}

function getApiBase() {
  if (typeof window !== "undefined" && window.location.port === "3000") {
    return `${window.location.protocol}//${window.location.hostname}:4000`
  }
  return ""
}

export function useMetrics(userId: number) {
  const apiBase = getApiBase()
  const [types, setTypes] = useState<MetricType[]>([])
  const [entries, setEntries] = useState<Record<number, MetricEntry[]>>({})
  const [loading, setLoading] = useState<boolean>(true)

  // Fetch metric types
  useEffect(() => {
    setLoading(true)
    fetch(`${apiBase}/api/metrics/types/${userId}`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch metric types")
        return res.json()
      })
      .then((data: MetricType[]) => setTypes(data))
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [apiBase, userId])

  // Fetch entries for one metric type
  function loadEntries(metricTypeId: number) {
    fetch(`${apiBase}/api/metrics/entries/${metricTypeId}`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch entries")
        return res.json()
      })
      .then((data: MetricEntry[]) =>
        setEntries((prev) => ({ ...prev, [metricTypeId]: data }))
      )
      .catch(console.error)
  }

  // Add a new entry
  function addEntry(
    metricTypeId: number,
    entry_date: string,
    value: number,
    note?: string
  ) {
    return fetch(`${apiBase}/api/metrics/entries`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ metric_type_id: metricTypeId, entry_date, value, note: note ?? null }),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Failed to save entry")
        return res.json()
      })
      .then((newEntry: MetricEntry) => {
        setEntries((prev) => ({
          ...prev,
          [metricTypeId]: [newEntry, ...(prev[metricTypeId] || [])],
        }))
      })
  }

  // Add a new metric type
  function addMetricType(
    name: string,
    unit: string | null,
    goal: number | null
  ): Promise<MetricType> {
    return fetch(`${apiBase}/api/metrics/types`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: userId, name, unit, goal }),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Failed to create metric type")
        return res.json() as Promise<MetricType>
      })
      .then((newType) => {
        setTypes((prev) => [...prev, newType])
        return newType
      })
  }

  // Delete a metric type (and its entries)
  function deleteMetricType(metricTypeId: number): Promise<void> {
    return fetch(`${apiBase}/api/metrics/types/${metricTypeId}`, {
      method: "DELETE",
    })
      .then((res) => {
        if (!res.ok) throw new Error("Failed to delete metric")
        // Remove from local state
        setTypes((prev) => prev.filter((t) => t.id !== metricTypeId))
        setEntries((prev) => {
          const next = { ...prev }
          delete next[metricTypeId]
          return next
        })
      })
  }

  return {
    types,
    entries,
    loading,
    loadEntries,
    addEntry,
    addMetricType,
    deleteMetricType,  // ← now exposed
  }
}
