// src/components/journalComponents/JournalPage.tsx
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

import { useMetrics, MetricEntry, MetricType } from "@/hooks/useMetrics"
import { MetricDropdown } from "./metricDropdown"
import { MetricSummaryCard } from "./metricSummaryCard"
import { MetricChart } from "./metricChart"
import { LogEntryForm } from "./logEntryForm"
import { LogEntryList } from "./logEntryList"
import { AddMetricForm } from "./addMetricForm"

export default function JournalPage() {
  const userId = 1
  const {
    types,
    entries,
    loading,
    loadEntries,
    addEntry,
    addMetricType,
    deleteMetricType,
  } = useMetrics(userId)

  const [selectedMetricId, setSelectedMetricId] = useState<number>()
  const [showForm, setShowForm] = useState(false)
  const [showAddMetric, setShowAddMetric] = useState(false)

  // Auto-select first metric once loaded
  useEffect(() => {
    if (types.length > 0 && selectedMetricId === undefined) {
      setSelectedMetricId(types[0].id)
    }
  }, [types, selectedMetricId])

  // Load entries for the selected metric
  useEffect(() => {
    if (selectedMetricId != null) {
      loadEntries(selectedMetricId)
    }
  }, [selectedMetricId, loadEntries])

  if (loading) return <div>Loading your metrics…</div>

  const selectedType: MetricType | undefined = types.find(
    (t) => t.id === selectedMetricId
  )

  // When no metrics exist yet and we're not adding one
  if (!selectedType && !showAddMetric) {
    return (
      <div className="p-4 max-w-4xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <div>No metrics yet.</div>
          <Button variant="outline" onClick={() => setShowAddMetric(true)}>
            + Add New Metric
          </Button>
        </div>
      </div>
    )
  }

  // Prepare entry lists once a metric is selected
  const rawEntries: MetricEntry[] =
    selectedMetricId != null ? entries[selectedMetricId] || [] : []

  const entryListItems = rawEntries.map((e) => ({
    date: e.entry_date,
    value: e.value,
    note: e.note ?? "",
  }))

  const chartData = rawEntries.map((e) => ({
    date: e.entry_date,
    value: e.value,
  }))

  const summaryMetric = selectedType && {
    name: selectedType.name,
    unit: selectedType.unit ?? "",
    goal: selectedType.goal ?? 0,
    entries: entryListItems,
  }

  const formMetric = selectedType && {
    id: selectedType.id.toString(),
    name: selectedType.name,
    unit: selectedType.unit ?? "",
  }

  return (
    <div className="p-4 max-w-4xl mx-auto space-y-6">
      {/* Top Section: Dropdown, Delete, Add Metric */}
      <div className="flex items-center justify-between space-x-4">
        {selectedType && (
          <div className="flex space-x-2">
            <MetricDropdown
              metrics={types.map((t) => ({
                id: t.id.toString(),
                name: t.name,
              }))}
              selectedMetricId={selectedType.id.toString()}
              onSelect={(id) => {
                setSelectedMetricId(Number(id))
                setShowForm(false)
                setShowAddMetric(false)
              }}
            />
            <Button
              variant="destructive"
              onClick={() => {
                if (
                  window.confirm(
                    "Are you sure you want to delete this metric and all its entries?"
                  )
                ) {
                  deleteMetricType(selectedType.id).then(() => {
                    setSelectedMetricId(undefined)
                    setShowForm(false)
                    setShowAddMetric(false)
                  })
                }
              }}
            >
              Delete
            </Button>
          </div>
        )}

        {!showAddMetric ? (
          <Button variant="outline" onClick={() => setShowAddMetric(true)}>
            + Add New Metric
          </Button>
        ) : (
          <AddMetricForm
            onCancel={() => setShowAddMetric(false)}
            onSave={(name, unit, goal) => {
              addMetricType(name, unit, goal).then((newType) => {
                setSelectedMetricId(newType.id)
                loadEntries(newType.id)
                setShowAddMetric(false)
              })
            }}
          />
        )}
      </div>

      {/* Main Content for Selected Metric */}
      {selectedType && summaryMetric && (
        <>
          <MetricSummaryCard metric={summaryMetric} />

          <Card>
            <CardHeader>
              <CardTitle className="text-red-600">
                {selectedType.name} Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <MetricChart entries={chartData} />
            </CardContent>
          </Card>

          {!showForm ? (
            <Button className="w-full" onClick={() => setShowForm(true)}>
              + Add Entry
            </Button>
          ) : (
            <LogEntryForm
              metric={formMetric!}
              onCancel={() => setShowForm(false)}
              onSubmit={({ date, value, note }) =>
                addEntry(selectedType.id, date, value, note).then(() =>
                  setShowForm(false)
                )
              }
            />
          )}

          <LogEntryList
            entries={entryListItems}
            unit={selectedType.unit ?? ""}
          />
        </>
      )}
    </div>
  )
}
