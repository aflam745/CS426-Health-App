// src/components/journalComponents/MetricSummaryCard.tsx
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { parseISO, format } from "date-fns"

interface Entry {
  date: string    // could be "YYYY-MM-DD" or full ISO
  value: number
  note?: string
}

interface MetricSummaryCardProps {
  metric: {
    name: string
    unit: string
    goal: number
    entries: Entry[]
  }
}

export function MetricSummaryCard({ metric }: MetricSummaryCardProps) {
  const { entries, unit, goal } = metric

  // Helper: take any ISO string and return "yyyy-MM-dd"
  const normalizeDay = (raw: string) => {
    const dt = parseISO(raw)
    return format(dt, "yyyy-MM-dd")
  }

  // 1) Build day → { total, count } map
  interface DayStats { total: number; count: number }
  const dayStats: Record<string, DayStats> = {}

  for (const { date, value } of entries) {
    const dayKey = normalizeDay(date)
    if (!dayStats[dayKey]) dayStats[dayKey] = { total: 0, count: 0 }
    dayStats[dayKey].total += value
    dayStats[dayKey].count += 1
  }

  // 2) Compute each day’s average
  const dailyAverages = Object.values(dayStats).map(
    ({ total, count }) => total / count
  )

  // 3) Then overall daily average
  const average =
    dailyAverages.length > 0
      ? dailyAverages.reduce((sum, a) => sum + a, 0) / dailyAverages.length
      : 0

  const latest = entries[0]?.value ?? "—"
  const status = goal
    ? average >= goal
      ? "Above Goal"
      : "Below Goal"
    : "No Goal"

  return (
    <Card>
      <CardHeader>
        <CardTitle>{metric.name} Overview</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <div>Status: <strong>{status}</strong></div>
        <div>Goal: <strong>{goal} {unit}</strong></div>
        <div>Average: <strong>{average.toFixed(1)} {unit}</strong></div>
        <div>Latest Entry: <strong>{latest} {unit}</strong></div>
      </CardContent>
    </Card>
  )
}
