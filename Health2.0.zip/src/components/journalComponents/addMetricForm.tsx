import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"

interface AddMetricFormProps {
  onCancel: () => void
  onSave: (name: string, unit: string | null, goal: number | null) => void
}

export function AddMetricForm({ onCancel, onSave }: AddMetricFormProps) {
  const [name, setName] = useState("")
  const [unit, setUnit] = useState("")
  const [goal, setGoal] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) {
      alert("Metric name is required.")
      return
    }
    const parsedGoal = goal.trim() ? parseFloat(goal) : null
    onSave(name.trim(), unit.trim() || null, isNaN(parsedGoal!) ? null : parsedGoal)
    setName("")
    setUnit("")
    setGoal("")
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col space-y-2 w-full max-w-sm">
      <Label>Name</Label>
      <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Blood Sugar" />

      <Label>Unit (optional)</Label>
      <Input value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="e.g. mg/dL" />

      <Label>Goal (optional)</Label>
      <Input
        type="number"
        inputMode="decimal"
        value={goal}
        onChange={(e) => setGoal(e.target.value)}
        placeholder="e.g. 120"
      />

      <div className="flex justify-between pt-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">Add Metric</Button>
      </div>
    </form>
  )
}
