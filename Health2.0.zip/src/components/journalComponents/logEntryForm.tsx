// src/components/journalComponents/LogEntryForm.tsx
import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

interface LogEntry {
  date: string
  value: number
  note?: string
}

interface LogEntryFormProps {
  metric: { id: string; name: string; unit: string }
  onCancel: () => void
  onSubmit: (entry: LogEntry) => void
}

export function LogEntryForm({ metric, onCancel, onSubmit }: LogEntryFormProps) {
  const today = new Date().toLocaleDateString("en-CA") // "YYYY-MM-DD"
  const [date, setDate] = useState<string>(today)
  const [value, setValue] = useState<string>("")
  const [note, setNote] = useState<string>("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const numericValue = Number(value)
    if (isNaN(numericValue) || numericValue <= 0) {
      alert("Enter a valid value.")
      return
    }
    // Pass date string as‑is
    onSubmit({ date, value: numericValue, note: note || undefined })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="date">Date</Label>
        <Input
          type="date"
          id="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
      </div>
      <div>
        <Label htmlFor="value">
          {metric.name} ({metric.unit})
        </Label>
        <Input
          type="number"
          id="value"
          inputMode="decimal"
          placeholder={`Enter ${metric.unit}`}
          value={value}
          onChange={(e) => setValue(e.target.value)}
        />
      </div>
      <div>
        <Label htmlFor="note">Note (optional)</Label>
        <Textarea
          id="note"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </div>
      <div className="flex justify-between">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">Save Entry</Button>
      </div>
    </form>
  )
}
