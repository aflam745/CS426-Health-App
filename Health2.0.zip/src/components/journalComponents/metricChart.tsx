import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import { format, parseISO } from "date-fns"

interface Entry {
  date: string // ISO string or “YYYY-MM-DD”
  value: number
}

interface MetricChartProps {
  entries: Entry[]
}

export function MetricChart({ entries }: MetricChartProps) {
  // Sort by date (in case)
  const sorted = [...entries].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  )

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={sorted}
          margin={{ top: 10, right: 20, bottom: 20, left: 0 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="date"
            tickFormatter={(d) => format(parseISO(d), "MMM d")}
            interval={0}
          />
          <YAxis />
          <Tooltip
            labelFormatter={(label) => format(parseISO(label), "PPP")}
            formatter={(val: number) => [`${val}`, "Value"]}
          />
          <Line
            type="monotone"
            dataKey="value"
            stroke="#dc2626"
            strokeWidth={2}
            dot={{ r: 4 }}
            activeDot={{ r: 6 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

